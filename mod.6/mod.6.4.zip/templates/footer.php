
    <div class="clearfix">
        <?php showMenu($menu, false) ?>
    </div>

    <div class="footer">&copy;&nbsp;<nobr>2018</nobr> Project.</div>

</body>
</html>