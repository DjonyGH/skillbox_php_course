<?php
    require_once($_SERVER['DOCUMENT_ROOT'].'/templates/header.php');
?>
<div class="page-content">
    <h1>
        <?= $title; ?>
    </h1>
    <p>Здесь будет контент страницы "Новости".</p>
</div>


<?php
    require_once($_SERVER['DOCUMENT_ROOT'].'/templates/footer.php');
?>